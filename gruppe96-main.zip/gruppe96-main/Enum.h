/**
 * Deklarasjon av enum Boligtype
 */

#ifndef ENUM_H
#define ENUM_H

enum Boligtype { LEILIGHET, ENEBOLIG };

#endif 