/**
* Deklarasjon for funksjon som skriver ut hovedmeny
* 
* @file    Kunde.h
* @author  Stian MJ
*/

#include <iostream>

#ifndef __GLOBAL_H
#define __GLOBAL_H

void skrivMeny();

#endif // GLOBAL_H
 