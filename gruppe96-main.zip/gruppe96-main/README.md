## gruppe96

## Kontaktinformasjon

Amund Rekve:
- 958 76 487
- amundre@stud.ntnu.no

Ole Marcus Havaas Markussen:
- 45 25 77 95
- ommarkus@stud.ntnu.no

Stian Mortensen Johnsen:
- 414 59 989
- stianmjo@stud.ntnu.no